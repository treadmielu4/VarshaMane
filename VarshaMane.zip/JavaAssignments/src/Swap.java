
import java.util.Scanner;
public class Swap{
 public static void main(String[] args) {
   int x, y, z;
   Scanner in = new Scanner(System.in);

   System.out.println("Input 1st number: ");
   x = in.nextInt();
   System.out.println("Input 2nd number: ");
   y = in.nextInt();

   z = x;
   x = y;
   y = z;

   System.out.println(" Swapped numbers are:" + x + " and " + y);
   in.close();
  }
}
