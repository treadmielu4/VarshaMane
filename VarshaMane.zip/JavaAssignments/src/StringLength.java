import java.util.Scanner;

class StringLength
{
	public static void main(String args[])
	{
		
		String str;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string :");
	 	str=sc.nextLine();
        sc.close();
		int n=str.length();
		
        	System.out.println("Length of the string = "+n);
		
	
	}
}