import java.util.Scanner;

class LastofIndex
{
	public static void main(String args[])
	{
		
		String str;
		String Char;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string :");
	 	str=sc.nextLine();
	 	
	 	System.out.println("Enter the letter to know its last index :");
	 	Char=sc.next();
	 	System.out.println(str.lastIndexOf((String) Char));
	 	sc.close();
	
	}
}