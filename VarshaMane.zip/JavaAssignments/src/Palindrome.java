import java.util.Scanner;

class Palindrome {
	 public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);
		System.out.print("Enter Number: ");
		int n = inp.nextInt();
		int a, s = 0, m = n;
        inp.close();
		while (n != 0) 
		{
			a = n % 10;
			s = s * 10 + a;
			n = n / 10;
		}

		if (m == s) // Checking if reverse and original are identical.
			System.out.println(m + " is a Palindrome Number");
		else
			System.out.println(m + " is not a Palindrome Number");

	}
}