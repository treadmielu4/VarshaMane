import java.util.Scanner;  

import java.lang.Math;  

public class Circle  

{  
public static void main(String[] args)   {  
	
double circumference, radius, area;  

Scanner sc=new Scanner (System.in); 

System.out.print("Give the radius of the circle: ");

radius=sc.nextDouble();  
 
area=Math.PI*(radius*radius);  

System.out.println("The area of the circle is: "+area);  
 

circumference= Math.PI*2*radius;  

System.out.println("The circumference of the circle is: "+circumference);  
sc.close();

}    
}    