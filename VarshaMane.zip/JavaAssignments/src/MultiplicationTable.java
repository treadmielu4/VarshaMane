import java.util.Scanner;

public class MultiplicationTable {

    public static void main(String[] args) {
    	int num;
    	System.out.println("�nter a Number :");
        Scanner scanner = new Scanner(System.in);
        num = scanner.nextInt();
        scanner.close();
       
        for(int i = 1; i <= 10; ++i)
        {
            System.out.printf("%d * %d = %d \n", num, i, num * i);
        }
    }
}