import java.util.Scanner;  

class SwapWithoutTemp   
{  
    public static void main(String a[])   
    {   
        System.out.println("Enter the values of x and y :\n");  
        Scanner sc = new Scanner(System.in);  
        
        int x = sc.nextInt();  
        int y = sc.nextInt();  
        System.out.println("Before Swapping Numbers: "+x +" "+ y);  
       
        x = x + y;   
        y = x - y;   
        x = x - y;   
        System.out.println("After Swapping Numbers: "+x +"  " + y); 
        sc.close();
    }   
}  