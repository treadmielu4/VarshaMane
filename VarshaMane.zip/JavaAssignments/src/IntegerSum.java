import java.util.Scanner;
public class IntegerSum {

  public static void main(String[] args)
    {
      Scanner in = new Scanner(System.in);
      System.out.print("Write an integer here: ");
      int digits = in.nextInt();
	  System.out.println("The sum is " + sumDigits(digits));
	  in.close();
    }

 public static int sumDigits(long n) {
		int result = 0;
		
		while(n > 0) {
			result += n % 10;
			n /= 10;
		}
		
		return result;
	}
	
 }

              